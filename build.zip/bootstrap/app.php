<?php

use App\Http\Middleware\CountSiteVisit;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

$app = Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
         $middleware->append(CountSiteVisit::class);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();

// Pasta pública renomeada para public_html (padrão de hospedagens cPanel)
$app->usePublicPath(dirname(__DIR__).'/public_html');

return $app;
