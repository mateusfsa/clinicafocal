<section id="agendamento" class="py-20 bg-light">
    <div class="container mx-auto px-5">
        <h2 class="section-title font-montserrat font-bold text-3xl md:text-4xl text-center relative mb-6">
            Agende sua Consulta</h2>
        <p class="text-lg text-gray-600 text-center max-w-3xl mx-auto mb-12">
            Preencha o formulário e nossa equipe entrará em contato para confirmar seu horário.</p>

        <div class="max-w-2xl mx-auto bg-white rounded-xl shadow-md p-8">
            <!--[if BLOCK]><![endif]--><?php if(session('agendamento_success')): ?>
                <div class="mb-6 p-4 rounded-lg bg-green-100 text-green-800">
                    <?php echo e(session('agendamento_success')); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <form wire:submit.prevent="solicitar">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                        <input type="text" wire:model="nome" placeholder="Nome completo"
                            class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base focus:border-primary focus:outline-none">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div>
                        <input type="tel" wire:model="telefone" placeholder="Telefone / WhatsApp"
                            class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base focus:border-primary focus:outline-none">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <div class="mt-5">
                    <input type="email" wire:model="email" placeholder="E-mail"
                        class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base focus:border-primary focus:outline-none">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="mt-5">
                    <select wire:model="medico_id"
                        class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base focus:border-primary focus:outline-none">
                        <option value="">Sem preferência de médico</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $medicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($medico->id); ?>"><?php echo e($medico->nome); ?> — <?php echo e($medico->especialidade); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['medico_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5 mt-5">
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Data preferida</label>
                        <input type="date" wire:model="data_preferida" min="<?php echo e(now()->toDateString()); ?>"
                            class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base focus:border-primary focus:outline-none">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['data_preferida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Período</label>
                        <select wire:model="periodo"
                            class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base focus:border-primary focus:outline-none">
                            <option value="manha">Manhã</option>
                            <option value="tarde">Tarde</option>
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['periodo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <div class="mt-5">
                    <textarea wire:model="mensagem" placeholder="Observações (opcional)"
                        class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base h-24 focus:border-primary focus:outline-none resize-y"></textarea>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['mensagem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="mt-5">
                    <label class="flex items-start gap-3 text-sm text-gray-600 cursor-pointer">
                        <input type="checkbox" wire:model="consentimento" class="mt-1 rounded border-gray-300">
                        <span>Autorizo o uso dos meus dados pessoais para fins de agendamento e contato,
                            conforme a Lei Geral de Proteção de Dados (LGPD).</span>
                    </label>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['consentimento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <button type="submit" wire:loading.attr="disabled"
                    class="mt-6 w-full bg-primary text-white font-montserrat font-bold py-4 rounded-lg hover:opacity-90 transition disabled:opacity-50">
                    <span wire:loading.remove>Solicitar Agendamento</span>
                    <span wire:loading>Enviando...</span>
                </button>
            </form>
        </div>
    </div>
</section>
<?php /**PATH C:\curso-laravel10\clinica-focal\resources\views/livewire/front/agendamento-section.blade.php ENDPATH**/ ?>