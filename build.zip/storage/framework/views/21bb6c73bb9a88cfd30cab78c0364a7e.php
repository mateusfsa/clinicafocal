   <section id="contato" class="py-20">
        <div class="container mx-auto px-5">
            <h2 class="section-title font-montserrat font-bold text-3xl md:text-4xl text-center relative mb-6">
                <?php echo e(get_option('contact_section_title')); ?></h2>
            <p class="text-lg text-gray-600 text-center max-w-3xl mx-auto mb-12">
                <?php echo e(get_option('contact_section_subtitle')); ?></p>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
                <div class="contact-info flex flex-col gap-6">
                    <div class="contact-item flex gap-4">
                        <div
                            class="contact-icon w-12 h-12 rounded-full bg-light flex items-center justify-center text-primary text-lg flex-shrink-0">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="contact-content">
                            <h4 class="font-montserrat font-bold text-dark mb-1">Endereço</h4>
                            <p class="text-gray-600"><?php echo e(get_option('contact_section_address')); ?></p>
                        </div>
                    </div>

                    <div class="contact-item flex gap-4">
                        <div
                            class="contact-icon w-12 h-12 rounded-full bg-light flex items-center justify-center text-primary text-lg flex-shrink-0">
                            <i class="fas fa-phone-alt"></i>
                        </div>
                        <div class="contact-content">
                            <h4 class="font-montserrat font-bold text-dark mb-1">Telefone</h4>
                            <p class="text-gray-600"><?php echo e(get_option('contact_section_phone')); ?></p>
                            <p class="text-gray-600"><?php echo e(get_option('whatsapp')); ?> (WhatsApp)</p>
                        </div>
                    </div>

                    <div class="contact-item flex gap-4">
                        <div
                            class="contact-icon w-12 h-12 rounded-full bg-light flex items-center justify-center text-primary text-lg flex-shrink-0">
                            <i class="far fa-envelope"></i>
                        </div>
                        <div class="contact-content">
                            <h4 class="font-montserrat font-bold text-dark mb-1">Email</h4>
                            <p class="text-gray-600"><?php echo e(get_option('contact_contact_section_email')); ?></p>
                        </div>
                    </div>

                    <div class="contact-item flex gap-4">
                        <div
                            class="contact-icon w-12 h-12 rounded-full bg-light flex items-center justify-center text-primary text-lg flex-shrink-0">
                            <i class="far fa-clock"></i>
                        </div>
                        <div class="contact-content">
                            <h4 class="font-montserrat font-bold text-dark mb-1">Horário de Funcionamento</h4>
                            <p class="text-gray-600"><?php echo e(get_option('contact_contact_section_time_1')); ?></p>
                            <p class="text-gray-600"><?php echo e(get_option('contact_contact_section_time_2')); ?></p>
                        </div>
                    </div>
                </div>

                <div class="contact-form">
                   <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('front.components.form-contact', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-594488245-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>
        </div>
    </section><?php /**PATH C:\curso-laravel10\clinica-focal\resources\views/livewire/front/contact-section.blade.php ENDPATH**/ ?>