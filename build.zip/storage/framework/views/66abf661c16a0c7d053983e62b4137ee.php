 <div>
     <form wire:submit.prevent="enviarEmail">
         <div class="mb-5">
             <input type="text" wire:model="name" placeholder="Nome Completo" required
                 class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base focus:border-primary focus:outline-none">
             <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
         </div>
         <div class="mb-5">
             <input type="email" wire:model="email" placeholder="Email" required
                 class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base focus:border-primary focus:outline-none">
             <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
         </div>
         <div class="mb-5">
             <input type="tel" wire:model="phone"placeholder="Telefone" required
                 class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base focus:border-primary focus:outline-none">
             <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
         </div>
         <div class="mb-5">
             <select required wire:model="service"
                 class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base focus:border-primary focus:outline-none">
                 <option value="" disabled selected>Selecione um serviço</option>
                 <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($service->link); ?>"><?php echo e($service->title); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
             </select>
             <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
         </div>
         <div class="mb-5">
             <textarea placeholder="Mensagem" wire:model="mensage" required
                 class="w-full px-4 py-3.5 border border-gray-300 rounded-lg font-sans text-base h-36 focus:border-primary focus:outline-none resize-y"></textarea>
             <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['mensage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
         </div>
         <button type="submit"
             class="btn px-8 py-3.5 bg-primary text-white rounded-full no-underline font-semibold uppercase tracking-wider text-sm shadow-custom transition-all hover:bg-secondary hover:-translate-y-1 hover:shadow-custom-hover w-full">Enviar
             Mensagem</button>
     </form>
 </div>
<?php /**PATH C:\curso-laravel10\clinica-focal\resources\views/livewire/front/components/form-contact.blade.php ENDPATH**/ ?>