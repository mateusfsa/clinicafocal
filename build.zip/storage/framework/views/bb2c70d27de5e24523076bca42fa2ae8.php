<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <title>Clinica Focal</title>

    <!-- Styles -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head>

<body class="font-sans text-gray-700 bg-gray-50 overflow-x-hidden">
    <!-- Botão WhatsApp -->
    <a href="https://api.whatsapp.com/send?phone=55<?php echo e(whatsapp_link()); ?>" class="whatsapp-button" target="_blank">
        <i class="fab fa-whatsapp"></i>
        <div class="tooltip">Fale conosco!</div>
    </a>
    <!-- Header -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('front.components.header', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4133151621-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <?php echo e($slot); ?>

    <!-- Footer -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('front.components.footer', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4133151621-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>   
</body>

</html>
<?php /**PATH C:\curso-laravel10\clinica-focal\resources\views/layouts/front.blade.php ENDPATH**/ ?>