 <header class="bg-white shadow-custom fixed w-full top-0 z-50">
     <div class="container mx-auto px-5 flex justify-between items-center py-4">
         <div class="logo flex items-center">
             <img src="<?php echo e(asset('storage/' . get_option('logo_site'))); ?>" alt="" class="h-10">
             <div class="font-montserrat font-bold dark:text-cyan-300 text-2xl px-2">
                 <?php echo get_option('title_site'); ?>                 
             </div>
         </div>
         <nav>
             <ul class="hidden md:flex space-x-4">
                 <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li><a href="<?php echo e($item->url); ?>"
                             class="nav-link relative font-semibold text-dark py-1 transition-all"><?php echo e($item->label); ?></a>
                     </li>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
             </ul>
             <button class="md:hidden bg-transparent border-none text-2xl cursor-pointer text-dark">
                 <i class="fas fa-bars"></i>
             </button>
         </nav>
     </div>
 </header>
<?php /**PATH C:\curso-laravel10\clinica-focal\resources\views/livewire/front/components/header.blade.php ENDPATH**/ ?>